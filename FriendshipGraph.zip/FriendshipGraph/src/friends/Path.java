package friends;

public class Path {
	public int counter;
	public String path;
	public Path(int c, String p) {
		this.counter=c;
		this.path=p;
	}
}
